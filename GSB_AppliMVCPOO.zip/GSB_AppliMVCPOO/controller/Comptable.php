<?php
class Comptable
{
    public function validerFrais($params)
    {

    }
}